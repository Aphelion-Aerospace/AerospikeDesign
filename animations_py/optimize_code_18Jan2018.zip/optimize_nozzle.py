import numpy as np 
import matplotlib.pyplot as plt
import gasdynamics as gd
from heat_flux import heat_flux
from plug_nozzle_angelino import plug_nozzle 
import MOC


## NASA CEA CONSTANTS
class CEA_constants():
	def __init__(self,gamma,T_c,p_c,rho_c,a_c,Pr,cp,c,w):
		self.gamma = gamma
		self.T_c = T_c
		self.p_c = p_c
		self.rho_c = rho_c
		self.a_c = a_c
		self.Pr = Pr 
		self.cp = cp 
		self.c = c
		self.w = w

def COST_FNC(design_alt,truncate_ratio,T_w,CEA,r_e,alpha,beta,n):

	### DESIGNING NOZZLE
	(p_atm,T_atm,rho_atm) = gd.standard_atmosphere(design_alt)

	PR = CEA.p_c/p_atm

	M_e = gd.PR_expansion_mach(PR,CEA.gamma)

	expansion_ratio = gd.expansion_ratio(1,M_e,CEA.gamma)#6.64 #8.1273
	print('Exp. ratio: ' + str(expansion_ratio))

	A_t = r_e**2*np.pi/expansion_ratio # max expansion (r_b = 0, r_e**2 >= A_t*expansion_ratio/np.pi)

	spike = plug_nozzle(expansion_ratio,A_t,r_e,CEA.gamma,CEA.T_c,CEA.p_c,CEA.a_c,CEA.rho_c,n,truncate_ratio = truncate_ratio)

	# Rotate nozzle about the x-axis
	spike.y = spike.y*-1
	spike.lip_y = spike.lip_y*-1

	### CALCULATING COST
	##	thurst estimation over altitude
	alt_range = np.linspace(0,12000,20)
	print(alt_range)
	thrust_range = np.zeros(alt_range.shape)
	for i in range (alt_range.shape[0]):
		if i==10:
			MOC_mesh = MOC.chr_mesh(spike,gamma,alt_range[i],50,downstream_factor=1.2,plot_chr=0)
		else:
			MOC_mesh = MOC.chr_mesh(spike,gamma,alt_range[i],50,downstream_factor=1.2,plot_chr=0)

		thrust_range[i] = MOC_mesh.compute_thrust('nearest',10)

	work = np.trapz(thrust_range,alt_range)
	plt.plot(alt_range,thrust_range,'o')
	plt.show()
	## heat transfer required
	total_heat_flux = heat_flux(CEA.Pr,CEA.cp,CEA.gamma,CEA.c,CEA.w,CEA.T_c,T_w,spike)

	print('Work: ' + str(work))
	print('Heat flux: ' + str(total_heat_flux))
	return alpha*work
# def COST(...alpha,beta):
# 	# spike = plug_nozzle(expansion_ratio,A_t,r_e,gamma,T_c,p_c,a_c,rho_c,n,truncate_ratio = 1)
# 	# heat = heat_flux(Pr,Cp,Gamma,c,w,To,spike)
# 	# thrust = MOC.thrust(...)
# 	return alpha*heat + beta*thurst
# 	# Pr = ??, c = ??, w = ??, To = Tc??

## CONSTANTS OF DESIGN FOR AERODYNAMICS
r_e = 0.067/2 #0.034 # likely too large
n = 1000

## NASA CEA CONSTANTS
gamma = 1.2381 #np.mean([1.2534,1.2852])
T_c = 2833.63
p_c = 34.474*10**5
rho_c = 3.3826
a_c = np.sqrt(gamma*(1-1/gamma)*200.07*T_c) 


#input variables from NASA CEA in metric units:
Pr=0.55645 #average throat to exit Prandtl's number
cp=1.724 #[KJ/KG-K] average throat to exit constant pressure heat capacity
c=0.003883468 #[millipoise/K^w] viscocity to temperature coefficient
w=0.678083301 #viscocity to temperature exponent

## CONSTANTS OF DESIGN FOR HEAT FLUX
#user input variable in metric units:
T_w=700 #[K] desired temperature of nozzle 


## CONSTANTS OF SIM
alpha = 1
beta = 0.2
design_alt = 6000
truncate_ratio = 0.1425 # bounds on truncate < 0.1425

CEA = CEA_constants(gamma,T_c,p_c,rho_c,a_c,Pr,cp,c,w)

print(COST_FNC(design_alt,truncate_ratio,T_w,CEA,r_e,alpha,beta,n))