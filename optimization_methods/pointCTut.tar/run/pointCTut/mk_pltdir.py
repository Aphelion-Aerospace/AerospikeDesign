#!/usr/bin/env python

import glob
import os

t_files=glob.glob("workdir.1/[0-9].[1-9]*");
timedirs=[];
for t in t_files:
	timedirs.append(t.split("/")[1]);
timedirs=sorted(timedirs);
workdirs=glob.glob("workdir.*");
n_few=len(timedirs)/len(workdirs);
d=1;
ggr=0;

os.system("cp -r temp_dir/* pltdir/");
os.system("rm -r pltdir/0.*");

for f in timedirs:
	if ggr >= n_few:
		d+=1;
		ggr=0;
	
	if d>len(workdirs):
		break;
	command="cp -r workdir."+str(d)+"/"+f+" pltdir/";
	os.system(command);
	ggr+=1;
	
