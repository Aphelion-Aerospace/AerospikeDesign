#!/usr/bin/python

import numpy as np
import sys

arr=np.loadtxt('forces/0.1/forceCoeffs.dat', delimiter='\t')
cd=np.mean(arr[10:,1]);

f=open(str(sys.argv[1]),"w");
f.write(str(cd))
f.close();
