/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright held by original author
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

\*---------------------------------------------------------------------------*/

#include "pointControlledDisplacement.H"
#include "pointPatchFields.H"
#include "addToRunTimeSelectionTable.H"
#include "Time.H"
#include "polyMesh.H"
#include "mathematicalConstants.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{

// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

pointControlledDisplacement::
pointControlledDisplacement
(
    const pointPatch& p,
    const DimensionedField<vector, pointMesh>& iF
)
:
    fixedValuePointPatchVectorField(p, iF)

{}


pointControlledDisplacement::
pointControlledDisplacement
(
    const pointPatch& p,
    const DimensionedField<vector, pointMesh>& iF,
    const dictionary& dict
)
:
    fixedValuePointPatchVectorField(p, iF, dict),
	movePoints_(dict.lookup("pointHandles")),
	handleRelations_(dict.lookup("handleRelations")),
	weights(movePoints_.size()),
	movement(this->patch().localPoints().size(),vector(0,0,0)),
	displacements_(movePoints_.size(),vector(0,0,0))
{
	snapToBoundary();
	setWeights();
	updateCoeffs();
}


pointControlledDisplacement::
pointControlledDisplacement
(
    const pointControlledDisplacement& ptf,
    const pointPatch& p,
    const DimensionedField<vector, pointMesh>& iF,
    const PointPatchFieldMapper& mapper
)
:
    fixedValuePointPatchVectorField(ptf, p, iF, mapper),
	movePoints_(ptf.movePoints_),
	handleRelations_(ptf.handleRelations_),
	weights(ptf.weights),
	movement(ptf.movement),
	displacements_(ptf.displacements_)
{}


pointControlledDisplacement::
pointControlledDisplacement
(
    const pointControlledDisplacement& ptf,
    const DimensionedField<vector, pointMesh>& iF
)
:
    fixedValuePointPatchVectorField(ptf, iF),
	movePoints_(ptf.movePoints_),
	handleRelations_(ptf.handleRelations_),
	weights(ptf.weights),
	movement(ptf.movement),
	displacements_(ptf.displacements_)

{}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //
void pointControlledDisplacement::updateCoeffs()
{

	if (this->updated())
    {
        return;
    }
	
    const polyMesh& mesh = this->dimensionedInternalField().mesh()();


	IOdictionary movementdict
	(
		IOobject
		(
			"pointMove",
			mesh.time().timeName(),
			mesh,
			IOobject::READ_IF_PRESENT,
			IOobject::AUTO_WRITE
		)
	);


	if (movementdict.readIfPresent("displacement",displacements_))
	{
			movement.resize(movement.size(),vector(0,0,0));
		
		forAll(displacements_,i)
		{
			
			forAll(movement,j)
			{
				movement[j] = movement[j] + weights[i][j]*displacements_[i];
			}
		}
	}
	
	Field<vector>::operator=(movement);
	fixedValuePointPatchVectorField::updateCoeffs();
}


void pointControlledDisplacement::write(Ostream& os) const
{
    pointPatchField<vector>::write(os);
    os.writeKeyword("pointHandles")
        << movePoints_<< token::END_STATEMENT << nl;
    os.writeKeyword("handleRelations")
        << handleRelations_ << token::END_STATEMENT << nl;
    writeEntry("value", os);
}


void pointControlledDisplacement::snapToBoundary()
{
	vectorField lP(this->patch().localPoints());
	scalarField closestPoint(movePoints_.size(),1);

	forAll(lP,i)
	{
		forAll(movePoints_,j)
		{
			if (
					mag(movePoints_[j]-lP[closestPoint[j]])>mag(movePoints_[j]-lP[i])
				)
			{
				closestPoint[j]=i;
			}
		}
	}

	forAll(movePoints_,k)
	{
		movePoints_[k]=lP[closestPoint[k]];
	}
}

void pointControlledDisplacement::setWeights()
{
	vector s(0,0,0);	// Normalized stop vector
	vector O(0,0,0);	// Origo vector
	vector a(0,0,0);	// 90 deg to stop vec
	vector p(0,0,0);	// Current handle relative 0
	vector lo(0,0,0);	// Current point relative 0
	vector bpl(0,0,0);	// Left bounding point	
	vector bpr(0,0,0);	// Right bounding point
	vectorField lp=this->patch().localPoints();
	int A=0; 
	int B=0;

	// Set stopping line
	forAll(handleRelations_,i)
	{
		if ( handleRelations_[i].z() > 0)
		{
			A = handleRelations_[i].x();
			B = handleRelations_[i].y();
			if (A != B)
			{
				s = movePoints_[B]-movePoints_[A];
				s = s/mag(s);
				O = movePoints_[A];
				break;
			}
		}
	}

	// Set weights
	forAll(movePoints_,i)
	{

		List<scalar> tempList(lp.size(),0.0);
		
		if (handleRelations_[i].z()<1)
		{
			p = movePoints_[i] - O;
			a = p - (p & s)*s;


			// This needs the points to be given sorted 
			bpl = movePoints_[handleRelations_[i].x()]-O;
			bpr = movePoints_[handleRelations_[i].y()]-O;

			forAll(lp,j)
			{
				lo = lp[j]-O;
				
				if ( correctSideOfStop(a,lo) && leftSideOfPoint(lo,p,s,bpl) && lo.z()<0.0001 )
				{
					// Compare to bpl
					tempList[j]=linearWeight(p-lo,p-bpl);

				}

				else if (correctSideOfStop(a,lo) && rightSideOfPoint(lo,p,s,bpr) && lo.z()<0.0001)
				{
					//Compare to bpr
					tempList[j]=linearWeight(p-lo,p-bpr);
				}
		
			}
		}

		weights[i].append(tempList);
	}

}

scalar pointControlledDisplacement::linearWeight(vector part, vector full)
{
	//return 1.0 - mag(part)/mag(full);
//	return 1-pow(mag(part)/mag(full),2);
	return pow(cos(mathematicalConstant::pi/2 * mag(part)/mag(full)),2);
}

bool pointControlledDisplacement::correctSideOfStop(vector a, vector lo)
{
	return (a & lo)>=0.0;
}

bool pointControlledDisplacement::leftSideOfPoint(vector lo, vector p, vector s, vector bpl)
{
	return (mag(lo & s)<=mag(p & s)) && (mag(lo & s) >= mag(bpl & s));
}

bool pointControlledDisplacement::rightSideOfPoint(vector lo, vector p, vector s, vector bpr)
{
	return (mag(lo & s)>=mag(p & s)) && (mag(lo & s)<=mag(bpr & s));
}

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

makePointPatchTypeField
(
    pointPatchVectorField,
    pointControlledDisplacement
);

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace Foam

// ************************************************************************* //
